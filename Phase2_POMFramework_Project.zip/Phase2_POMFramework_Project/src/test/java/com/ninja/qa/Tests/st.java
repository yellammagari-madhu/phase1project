package com.ninja.qa.Tests;

public interface st {

}