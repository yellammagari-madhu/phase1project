package java_fundamentals;

public class WhileLoop {
	public static void main(String[] args) {
        // Initialize a counter variable
        int counter = 1;

        // Use a while loop to print numbers from 1 to 5
        while (counter <= 5) {
            System.out.println("Number: " + counter);

            // Increment the counter
            counter++;
        }
    }

}
