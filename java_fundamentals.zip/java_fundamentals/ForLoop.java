package java_fundamentals;

public class ForLoop {
	public static void main(String[] args) {
        // Use a for loop to print numbers from 1 to 5
        for (int i = 1; i <= 5; i++) {
            System.out.println("Number: " + i);
        }
    }
}
